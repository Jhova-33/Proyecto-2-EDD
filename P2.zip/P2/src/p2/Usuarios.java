/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p2;

/**
 *
 * @author Andrea
 */
public class Usuarios {
    String nombre;
    String tipo;
    public Usuarios next;

    public Usuarios(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.next = null;
        
        
    }
    
    public void agregarUsuario(String nombre, String tipo) {
        this.nombre += nombre;
        this.tipo += tipo;
    }
    
    public String toString(){
        return "Usuario: "+nombre+" , Tipo: "+tipo;
    }
    
     public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }
    
    
}
