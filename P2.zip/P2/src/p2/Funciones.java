/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;


/**
 *
 * @author Andrea
 */
public class Funciones {
   
    private static ArrayList<Usuarios> usuarios1 = new ArrayList<>();
    private static ArrayList<Documentos> documentos = new ArrayList<>();
    
    
    public void cargarCSV(){
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Seleccione un archivo de tipo CSV");
        int seleccion = fileChooser.showOpenDialog(null);
        if (seleccion == JFileChooser.APPROVE_OPTION){
            String archivoCSV = fileChooser.getSelectedFile().getAbsolutePath();
            if (!archivoCSV.toLowerCase().endsWith(".csv")){
            JOptionPane.showMessageDialog(null,"Error, el archivo no es del tipo .CSV");
            return;
            }
            try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))){
            String linea;
            while((linea = br.readLine())!=null){
                String[] partes = linea.split(",");
                if (partes.length == 2){
                    String nombre = partes[0].trim();
                    String tipo = partes[1].trim();
                    
                    Usuarios usuario = new Usuarios(nombre,tipo);
                    usuarios1.add(usuario);
                    
                    System.out.println("Los usuarios agregados son:"+ usuarios1.toString());
                    
                }
            }
            }catch(IOException e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null,"Error: "+e.getMessage());
            }
        }else{
            JOptionPane.showMessageDialog(null, "Operación fallida.");
        }
        
        
    }
    
    public void agregarUsuarioManual(){
        
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre de usuario: ").trim().toLowerCase();
        String tipo = "prioridad_"+JOptionPane.showInputDialog("Ingrese el tipo de usuario /ejemplo: alta,media,baja /: ").trim().toLowerCase();
    
        Usuarios a = new Usuarios(nombre,tipo);
        usuarios1.add(a);
        System.out.println("El usuario agregado es:"+ a.toString());
                    
    
    }
    
    private void eliminarDocumentosUsuario(Usuarios usuario) {
        
        Iterator<Documentos> iterator = documentos.iterator();
        while (iterator.hasNext()) {
            Documentos documento = iterator.next();
            if (documento.getUsuario().equals(usuario)) {
                iterator.remove();
            }
        }
    }
    
    public void eliminarUsuario() {
        
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del usuario a eliminar: ").trim().toLowerCase();

        Iterator<Usuarios> iterator = usuarios1.iterator();
        while (iterator.hasNext()) {
            Usuarios usuario = iterator.next();
            if (usuario.getNombre().equals(nombre)) {
                iterator.remove();
                eliminarDocumentosUsuario(usuario);
                System.out.println("El usuario " + nombre + " y sus documentos han sido eliminados.");
                return;
            }
        }

        System.out.println("El usuario " + nombre + " no existe en la cola de impresión.");
    }
    
    
    
    public void agregarDocumento() {
        
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del documento: ").trim();
        int tamaño = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el tamaño del documento: "));
        String tipo = JOptionPane.showInputDialog("Ingrese el tipo del documento (prioridad_alta, prioridad_media, prioridad_baja): ").trim().toLowerCase();
        
        Documentos b = new Documentos(nombre, tamaño, tipo);
        documentos.add(b);
        System.out.println("El documento agregado es: " + b.toString());
        
            
    }
    
    
    
    public void imprimirDocumento() {
        
        if (documentos.isEmpty()) {
            System.out.println("No hay documentos en la cola de impresión.");
            return;
        }else{
            String nombre = JOptionPane.showInputDialog("Ingrese el nombre del documento: ").trim();
            
            documentos.remove(nombre);
            System.out.println("Imprimiendo documento: " + nombre.toString());
        }

        
    }
    
    public void eliminarDocumento() {
        
        if (documentos.isEmpty()) {
            System.out.println("No hay documentos en la cola de impresión.");
            return;
        }else{
            String nombre = JOptionPane.showInputDialog("Ingrese el nombre del documento: ").trim();
            documentos.remove(nombre);
            System.out.println("Ha sido eliminado el documento" + nombre.toString());
        }

        
    }

    public void ValidarUsuario(){
        String nombre = JOptionPane.showInputDialog("Nombre de usuario: ").trim().toLowerCase();
        if (usuarios1.contains(nombre)){
           JOptionPane.showMessageDialog(null, "Este usuario se encuentra en el sistema."); 
           
        }else{
            JOptionPane.showMessageDialog(null, "Este usuario no se encuentra en el sistema.");
            System.exit(0);
        }
        
    }
    
}
