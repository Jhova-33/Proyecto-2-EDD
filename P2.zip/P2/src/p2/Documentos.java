/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p2;

import java.util.List;

/**
 *
 * @author Andrea
 */
public class Documentos {
    private String nombre;
    private int tamaño;
    private String tipo;
    private Usuarios usuario;

    public Documentos(String nombre, int tamaño, String tipo) {
        this.nombre = nombre;
        this.tamaño = tamaño;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public int getTamaño() {
        return tamaño;
    }

    public String getTipo() {
        return tipo;
    }

    public Usuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuarios usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "Documento [nombre=" + nombre + ", tamaño=" + tamaño + ", tipo=" + tipo + "]";
    }
    
    
}
